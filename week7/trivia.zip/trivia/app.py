from flask import Flask, render_template, request
import json
import requests


import triviagame, triviaquestion



app = Flask(__name__)




#Get Methods
player=triviagame.TriviaGame()
newGame= player.retrieveQuestions("9", "10")
player.saveAllQuestions(newGame)

#Trivia Game
@app.route("/")
def playGame():
    return render_template("index.html", trivia_game= player.getAllQuestions())


#Trivia Game Score
@app.route('/score', methods=['POST'])
def getScore():
    correctlyAnsweredQuestions = []
    incorrectlyAnsweredQuestions = []
    for question in player.getAllQuestions():
        if request.form[str(question.getID())] == question.getCorrectAnswer():
            correctlyAnsweredQuestions.append(question)
        else: 
            incorrectlyAnsweredQuestions.append(question)
    return render_template("score.html", correct= correctlyAnsweredQuestions, incorrect=incorrectlyAnsweredQuestions)


if __name__ == "__main__":
    app.run()