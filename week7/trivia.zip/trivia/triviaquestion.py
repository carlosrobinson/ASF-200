import random, copy
import itertools
from random import shuffle

class TriviaQuestion:
    id_iter=itertools.count(1)
    """Randomly generated trivia questions"""
    def __init__(self,  question, category, difficulty, correct_answer, incorrect_answers):
        self.id=next(self.id_iter)
        self.question=question
        self.category=category
        self.difficulty=difficulty
        self.correct_answer=correct_answer
        self.incorrect_answers=incorrect_answers



    def getID(self):
        return self.id



    def get_Question(self):
        return self.question



    def getCategory(self):
        return self.category



    def getDifficulty(self):
        return self.difficulty



    def getCorrectAnswer(self):
        # print(self.correct_answers)
        return self.correct_answer



    def getIncorrectAnswers(self):
        return self.incorrect_answers




    def getShuffledAnswers(self):
        self.answers=[]
        self.answers=self.incorrect_answers.copy()
        self.answers.append(self.correct_answer)
        random.shuffle(self.answers)
        # print(self.answers)
        return self.answers

    def showScore(self):
            return self.correct_answer



    def __str__(self):
        return f'{self.id} ". " {self.question} "\n" {self.answers}'



    def __rep__(self):
        return f'{self.id} ". " {self.question} "\n" {self.answers}'

