
import requests, triviaquestion, random


class TriviaGame():
    def __init__(self):
        self.trivia_questions=[]
        
    
    
    
    def addQuestions(self, results):
        self.trivia_questions.append(results)


    def getAllQuestions(self):
        return self.trivia_questions




    def retrieveQuestions(self, catID, numQuestions):
        URL=f"https://opentdb.com/api.php?amount={numQuestions}&category={catID}&difficulty=medium&type=multiple"
        try:
            response=requests.get(URL, timeout=5)
            response.raise_for_status()
            response_JSON=response.json()
            return response_JSON
        except requests.exceptions.HTTPError as errh:
            print(errh)
        except requests.exceptions.ConnectionError as errc:
            print(errc)
        except requests.exceptions.Timeout as errt:
            print(errt)
        except requests.exceptions.RequestException as err:
            print(err)



    def saveAllQuestions(self, retrieved_questions):

        for challenge in retrieved_questions['results']:
        
            founded_challenge=triviaquestion.TriviaQuestion(
                challenge["question"],
                challenge["category"],
                challenge["difficulty"],
                challenge["correct_answer"],
                challenge["incorrect_answers"]
            )
            self.trivia_questions.append(founded_challenge)


