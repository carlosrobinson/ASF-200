

from flask import Flask, render_template, request

import requests
import json
import addressbook


app = Flask(__name__)


# Get Data
def getContacts(limit, nat):
    """Retrieve data from the API"""
    try:
        response = requests.get(f"https://randomuser.me/api/?results={limit}&nat={nat}", timeout=5)
        response.raise_for_status() # check for errors
        response_JSON = response.json()
        return response_JSON
    except requests.exceptions.HTTPError as errh:
        print(errh)
    except requests.exceptions.ConnectionError as errc:
        print(errc)
    except requests.exceptions.Timeout as errt:
        print(errt)
    except requests.exceptions.RequestException as err:
        print(err)




# Variable for data(JSON)
phoneBook = getContacts(10, "us")
confirmedAddresses = addressbook.AddressBook()
for person in phoneBook["results"]:
    
    first_name = person["name"]["first"]
    last_name = person["name"]["last"]
    email = person["email"]
    phone = person["phone"]
    photo = person["picture"]["thumbnail"]
    newUser=addressbook.Contact(first_name, last_name, email, phone, photo)
    confirmedAddresses.addAddress(newUser)






@app.route('/search', methods=['POST'])
def displaySearch():
    searchStr = request.form.get('search')
    return render_template('index.html', myContact = confirmedAddresses.findAllMatching(searchStr))



@app.route("/")
def displayContacts():
    confirmedAddresses.getAllAddresses()
    return render_template('index.html', myContact =confirmedAddresses.getAllAddresses())



if __name__ == "__main__":
    app.run()