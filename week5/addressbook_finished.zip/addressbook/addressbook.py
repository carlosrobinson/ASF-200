class Contact():
    def __init__(self, first, last, email, phone, photo):
        self.__first= first
        self.__last=last
        self.__email=email
        self.__phone=phone
        self.__photo=photo





# first Name
    def getFirstName(self ):
        return self.__first




    def setFirstName(self,first):
        self.__first = first




# last Name
    def getLastName(self ):
        return self.__last




    def setLastName(self,last):
        self.__last = last




# Email
    def getEmail(self ):
        return self.__email




    def setEmail(self,email):
        self.__email = email



# Phone
    def getPhone(self ):
        return self.__phone




    def setPhone(self,phone):
        self.__phone = phone




# Photo
    def getPhoto(self ):
        return self.__photo



    def setPhoto(self,photo):
        self.__photo = photo



    def __str__(self):
        retStr = self.__first
        retStr+= ' '
        retStr += self.__last
        retStr+= '\n'
        retStr += self.__email
        retStr+= '\n'
        retStr += self.__phone
        retStr+= '\n'
        retStr += self.__photo
        retStr+= '\n'
        return retStr




    def __rep__(self):
        retStr = self.__first
        retStr+= ' '
        retStr += self.__last
        retStr+= '\n '
        retStr += self.__email
        retStr+= '\n '
        retStr += self.__phone
        retStr+= '\n '
        retStr += self.__photo
        return retStr

        
class AddressBook():
    def __init__(self):
        self.addresses = []



        
    def addAddress(self,address):
        self.addresses.append(address)
        



    def getAllAddresses(self):
        return self.addresses
    



    def findAllMatching(self,searchStr):
        results = []
        for address in self.addresses:
            if address.getFirstName().lower().startswith(searchStr.lower()) or address.getLastName().lower().startswith(searchStr.lower()):
                results.append(address)
        return results
    
   